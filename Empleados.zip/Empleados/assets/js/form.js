$(document).read(function(){

    $("#FormEmpleado").validate({
        rules:{
            nombre: "required",
            email: "required"
        },
        submitHandler: function(form){
        form.submit();
        }
    });

});