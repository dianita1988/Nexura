<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MARea extends CI_Model {
	
	public function __construct(){
		parent::__construct();
	}

	public function GuardarArea($nombre)
{
		$sql = "INSERT INTO areas (nombre) VALUES('$nombre')";
		$datos = $this->db->query($sql);
		return $this->db->error();
		
}

public function EliminarArea($id)
{
		$sql = "DELETE FROM areas WHERE id = $id";
		$this->db->query($sql);
		return $this->db->error();
		
}

public function ModificArea($id, $nombre){
	$sql = "UPDATE areas SET nombre = $nombre WHERE id = $id";
	$datos = $this->db->query($sql);
	return $this->db->error();
}

}
