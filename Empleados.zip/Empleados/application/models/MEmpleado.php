<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MEmpleado extends CI_Model {
	
	public function __construct(){
		parent::__construct();
	}

	public function TablaArea(){
		$sql = "SELECT * FROM areas";
		$datos = $this->db->query($sql)->result_array();
		return $datos; 
	}

    public function TablaRoles(){
		$sql = "SELECT * FROM roles";
		$datos = $this->db->query($sql)->result_array();
		return $datos;
	}

    public function TablaEmpleado(){
		//$sql = "SELECT empleados.id, empleados.nombre, empleados.email,empleados.sexo,empleados.boletin,empleados.descripcion,areas.id as idarea,areas.nombre as nomarea, empleados.foto_empleado FROM `empleados`, `areas`where empleados.areas_id = areas.id order by empleados.id DESC";
		$sql="SELECT  
		emp.id,
		emp.nombre,
		emp.sexo,
		emp.email,
		ar.nombre as nomarea,
		emp.areas_id as idarea,
		emp.boletin,
		emp.descripcion,
		emp.foto_empleado,
		emprol.empleados_id,
		emprol.roles_id AS ROLES
		FROM empleados emp
		INNER JOIN empleados_roles emprol ON emp.id = emprol.empleados_id
		INNER JOIN areas ar ON emp.areas_id = ar.id";
		//WHERE emprol.empleados_id = 54";
		$datos = $this->db->query($sql)->result_array();
		return $datos;
	}

	public function ConsultaRol($id){
		$sql = "SELECT * FROM empleados_roles WHERE empleados_id = '$id'";
		$datos = $this->db->query($sql)->result_array();
		return $datos;
	}


public function GuardarEmpl($nombre,$email,$sexo,$area,$boletin,$descripcion,$foto)
{
		$sql = "INSERT INTO empleados (nombre, email, sexo, areas_id, boletin, descripcion,foto_empleado) VALUES('$nombre','$email',$sexo,$area,$boletin,'$descripcion','$foto')";
		$datos = $this->db->query($sql);
		return $this->db->insert_id();
		
}
public function GuardarRol($id,$rol)
{
		$sql = "INSERT INTO empleados_roles VALUES('$id','$rol')";
		$datos = $this->db->query($sql);
		return $this->db->error();
}

public function EliminarEmpl($id)
{
		$sql = "DELETE FROM empleados_roles WHERE empleados_id = $id";
		$this->db->query($sql);
		$sql = "DELETE FROM empleados WHERE id = $id";
		$this->db->query($sql);
		return $this->db->error();
		
}

public function ModificarEmpl($id,$nombre,$email,$sexo,$area,$boletin,$descripcion,$foto)
{
		$sql = "UPDATE empleados
				SET nombre = '$nombre', email = '$email', sexo = $sexo, areas_id = $area, boletin = $boletin, descripcion = '$descripcion', foto_empleado = '$foto'
		WHERE id = $id";
		$datos = $this->db->query($sql);
		return $this->db->insert_id();
		
}

public function ModificarRol($id,$rol)
{
		$sql = "UPDATE empleados_roles SET roles_id = $rol WHERE empleados_id = $id";
		$datos = $this->db->query($sql);
		return $datos;
}

}
