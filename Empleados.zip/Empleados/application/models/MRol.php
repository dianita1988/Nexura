<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MRol extends CI_Model {
	
	public function __construct(){
		parent::__construct();
	}

	public function GuardarRol($nombre)
{
		$sql = "INSERT INTO roles (nombre) VALUES('$nombre')";
		$datos = $this->db->query($sql);
		return $this->db->error();
		
}

public function EliminarRol($id)
{
		$sql = "DELETE FROM roles WHERE id = $id";
		$this->db->query($sql);
		return $this->db->error();
		
}

public function ModificRol($id, $nombre){
	$sql = "UPDATE roles SET nombre = '$nombre' WHERE id = $id";
	$datos = $this->db->query($sql);
	return $this->db->error();
}

}
