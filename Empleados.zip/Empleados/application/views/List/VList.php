<!-- Begin Page Content -->
<div class="container-fluid">

<div class="row text-align"  >
        <div class="col-md-9">
            <div class="card shadow mb-6" id="formModifi">
            <div class="col-lg-3">
					<div class="section-body" >
					<button type="button" class="btn ink-reaction btn-danger btncerrar" id="btncerrar" > X</button>
					</div>	
				</div>
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold" style="color: red;">Formulario de modificación de empleados</h6>
                </div>
                <div class="card-body">
                    <form id="FormModEmpleado" class="form-horizontal FormEmpleado" onsubmit="return false;" enctype="multipart/form-data">
                    
                    <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label  for="">Foto Empleado: </label>
                                </div>
                                <div class="col-md-8">
                                    <input type="hidden"  class="form-control" id="fot" name="fot">
                                    <img src="" alt="" id="imgfoto" name="imgfoto" width="40%">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label  for="">Nombre completo: * </label>
                                </div>
                                <div class="col-md-8">
                                <input type="hidden"  class="form-control" id="id" name="id">
                                    <input type="text" placeholder="Nombre completo del empleado" class="form-control" id="nombre1" name="nombre1">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="">Correo electrónico: *  </label>
                                </div>
                                <div class="col-md-8">
                                    <input type="email" placeholder="Correo electrónico" class="form-control" id="email1" name="email1">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="">Sexo: *  </label>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="sexo1" id="sexo1" value="1" >
                                        <label class="form-check-label" for="f">
                                        Femenino
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="sexo1" id="sexo1" value="2">
                                        <label class="form-check-label" for="m">
                                        Masculino
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="">Área: *  </label>
                                </div>
                                <div class="col-md-8">
                                    <select class="form-control" name="areas1" id="areas1">
                                    <?php foreach ($area as $ar) {?>
                                        <option  value="<?php echo $ar['id']; ?>"><?php echo $ar['nombre']; ?></option>';
                                     <?php }?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="">Descripción: *  </label>
                                </div>
                                <div class="col-md-8">
                                    <textarea placeholder="Descripción de la experiencia del empleado" class="form-control" id="descripcion1" name="descripcion1"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                </div>
                                <div class="col-md-8">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="boletin1" id="boletin1" value="1">
                                        <label class="form-check-label" for="f">
                                        Deseo recibir boletín informativo.
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="" id="ro" name="ro">Roles: *  </label>
                                </div>
                                <div class="col-md-8">
                                <?php foreach ($roles as $rol) {?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="rol1[]" id="rol<?php echo $rol['id'];?>" value="<?php echo $rol['id'];?>" >
                                        <label class="form-check-label" >
                                        <?php echo $rol['nombre']; ?>
                                        </label>
                                    </div>
                                    <?php }?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="">Cambiar foto Empleado: </label>
                                </div>
                                <div class="col-md-8">
                                <label id="peso" name="peso">Peso Máximo: 200 kb, </label><label id="form" name="form"> Formato: "jpg", "png" </label>
                                <input type="file" id="file" name="file" />
                                </div>
                            </div>
                        </div>

                        <br>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                </div>
                                <div class="col-md-8">
                                <button type="submit" class="btn btn-danger" id="BtnModificarEmpleado" >Guardar cambios</button>
                                </div>
                            </div>
                        </div>
                    
                </form>
            </div>
        </div>
    </div>


    <div class="col-md-12" id="tablaEmpleado">
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold" style="color: red;">Tabla de registros</h6>
            </div>
            <div class="card-body">
                    <table id="TablaEmpleado" width="100%" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>NOMBRE COMPLETO</th>
                                <th>EMAIL</th>
                                <th>SEXO</th>
                                <th>AREA</th>
                                <th>FOTO</th>
                                <th>IDAREA</th>
                                <th>BOLETIN</th>
                                <th>DESCRIPCION</th>
                                <th>ROLES</th>
                                <th>ACCIONES</th>                           
                            </tr>
                        </thead>
                    </table>
            </div>
        </div>
    </div>
</div>