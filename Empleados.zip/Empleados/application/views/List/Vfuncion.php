<script type="text/javascript">
 document.getElementById("formModifi").style.display = "none";
    $(document).ready(function() {
        $('#TablaEmpleado').DataTable( {
            "processing": true,
            "serverSide": false,
            "responsive": true,
            "language": {
                "url": "./assets/Spanish.json"
            },
            "ajax": {
                "url": "Lista/TablaEmpleado",
                "type": "POST"
            },
            "columns": [
            { "data": "id" },
            { "data": "nombre" },
            { "data": "email" },
            { "data": "sexo","render": function ( data, type, row ) {
              if(row.sexo == '1'){
                return "Femenino"
              }else{
                return "Masculino"
              }
            }},
            { "data": "nomarea" },
            { "data": "foto_empleado",visible: false },
            { "data": "idarea",visible: false },
            { "data": "boletin","render": function ( data, type, row ) {
              if(row.boletin == '1'){
                return "Si"
              }else{
                return "No"
              }

            }}, 
            { "data": "descripcion" ,visible: false },
			{ "data": "rolestotales" ,visible: false },
            {'data': null, "className": "text-center",
            'render': function (data, type, row) 
             {
                return '<button  class="btn .ink-reaction btn-info" onclick="editarregistro('+row.id+',\''+ row.nombre + '\',\''+ row.email + '\',\''+ row.sexo + '\',\''+ row.idarea + '\',\''+ row.boletin+ '\',\''+ row.descripcion + '\',\''+ row.foto_empleado + '\',\''+ row.rolestotales + '\')"><i class="fa fa-fw fa-edit"></i></button><button  class="btn .ink-reaction btn-danger" onclick="eliminarregistro('+row.id+',)"><i class="fas fa-trash-alt"></i></button>';
             }
        },
            ]
        } );
    } );

    function refrescartabla(){
    var table = $('#TablaEmpleado').DataTable();
     table.ajax.reload(null,false);  
    }

    $("#btncerrar").click(function() {
      document.getElementById("formModifi").style.display = "none";
      document.getElementById("tablaEmpleado").style.display = "block";
});

    function eliminarregistro(id)
{
  alert(id);
  Swal.fire({
  title: '¿Estás seguro?',
  text: "Que desea eliminar esta empleado",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Si'
}).then((result) => {
  if (result.isConfirmed) {
    $.ajax({
          type:"post",
          url: "Lista/eliminar",
          data: {id}
		  })
          .done(function(response) {
			if (response.codigo== 1) {
				Swal.fire({
							  icon: 'error',
							  title: response.mensaje,
							  showConfirmButton: false,
							  timer: 3000
							})
			}else{

				Swal.fire({
					  icon: 'success',
					  title: 'Registro Eliminado',
					  showConfirmButton: false,
					  timer: 1500
					}).then(() => {

						 location.href = 'Lista'
					})
			}
		})


  } else {
}
})
}

function editarregistro(id,nombre,email,sexo,idarea,boletin,descripcion,foto_empleado, roles)
{
$("#rol1,#rol2,#rol3").prop("checked", false);
  document.getElementById("formModifi").style.display = "block";
  document.getElementById("tablaEmpleado").style.display = "none";
  if (foto_empleado == "") {
	  foto = "./assets/img/sin-foto.jpg";
	  $("#imgfoto").attr("src",foto);
  }else{
	$("#imgfoto").attr("src",foto_empleado);
  }
  $("#fot").val(foto_empleado);
  $("#id").val(id);
  $("#nombre1").val(nombre);
  $("#email1").val(email);
  if(boletin == '1'){
    $("#boletin1").prop("checked", true);
  }
  $("input[name=sexo1]").val([sexo]);
  $("#areas1").val(idarea);
  $("#descripcion1").val(descripcion);
//   console.log($('input[name="rol1[]"]:checkbox').length);
  let roles2 = roles.split(",");
  var  cant = $('input[name="rol1[]"]:checkbox').length;
  var  sel = 0;
let se = 1;
  var che = roles2.length;
//   console.log(cant);
//   console.log(che);
  while (se <= che) {
	var nm = roles2[sel];
	//console.log(nm);
	$("#rol"+nm).prop("checked", true);		
	sel ++;
	se++;
  }	
	//   if (roles2.includes('1')) {
	// 	$("#rol1").prop("checked", true);
	//   }
	//   if (roles2.includes('2')) {
	// 	$("#rol2").prop("checked", true);
	//   }
	//   if (roles2.includes('3')) {
	// 	$("#rol3").prop("checked", true);
	//   }
}

$("#BtnModificarEmpleado").click(function() {
    if($("#nombre1").val() == "")
		{
		    $("#nombre1").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#nombre1").css({"border":"1px solid green"});
		}
		
		if($("#email1").val() == "" ){
		        $("#email1").css({"border":"1px solid red"});
		        return false;
		}else{
		   valor =$("#email1").val();
		    re=/^([\da-z_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
	        if(!re.exec(valor)){
	             $("#email1").css({"border":"1px solid red"});
        		return false;
        	}else {
        	    $("#email1").css({"border":"1px solid green"});
        	}
		}
		
        if($("#area1").val() == "")
		{
		    $("#area1").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#area1").css({"border":"1px solid green"});
		}

        if($("#descripcion1").val() == "")
		{
		    $("#descripcion1").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#descripcion1").css({"border":"1px solid green"});
		}

        if($("#boletin1").val() == "")
		{
		    $("#boletin1").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#boletin1").css({"border":"1px solid green"});
		}

		var rolSeleccionados = new Array();
    $('input[type=checkbox]:checked').each(function() {
		rolSeleccionados.push($(this).val());
    });
		// var  cant = $('input[name="rol1[]"].checked').length
		// console.log(cant);
		if(rolSeleccionados == ""){
			$("#ro").css({"color":"red"});
			return false;
		}else{
			$("#ro").css({"color":"green"});
		}


		// if($("#file").val() == ""){
		// 		$("#file").css({"color":"red"});
		//     	return false;
		// 	}else{
		// 		$("#file").css({"color":"green"});
		// 	}

		if($("#sexo1").val() == ""){
		     $("#sexo1").css({"border":"1px solid red"});
		     return false;
		}else{
		    $("#sexo1").css({"border":"1px solid green"});

    var formData = new FormData($("#FormModEmpleado")[0]);
		$.ajax({
			url: 'Lista/modificar',
			type: 'POST',
			enctype: 'multipart/form-data',
			dataType: 'json',
			processData: false,
			contentType: false,
			cache: false,
			// data: $("#FormEmpleado").serialize() + "&file="+files,
			data: formData
		})
		.done(function(response) {
			if (response.codigo== 1) {
				Swal.fire({
							  icon: 'error',
							  title: response.mensaje,
							  showConfirmButton: false,
							  timer: 3000
							})
			}else{
				Swal.fire({
					  icon: 'success',
					  title: 'Registro Actualizado',
					  showConfirmButton: false,
					  timer: 1500
					}).then(() => {
						 location.href = 'Lista'
					})
			}
		})
		.fail(function() {
			console.log("error");
		})
  	}
});

</script> 