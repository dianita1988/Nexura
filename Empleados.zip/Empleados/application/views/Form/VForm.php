<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="row text-align">
        <div class="col-md-8">
            <div class="card shadow mb-6">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold" style="color: red;">Formulario de registro de empleados</h6>
                </div>
                <div class="card-body">
                    <form id="FormEmpleado" class="form-horizontal FormEmpleado" onsubmit="return false;" enctype="multipart/form-data">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label  for="">Nombre completo: * </label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" placeholder="Nombre completo del empleado" class="form-control" id="nombre" name="nombre">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="">Correo electrónico: *  </label>
                                </div>
                                <div class="col-md-8">
                                    <input type="email" placeholder="Correo electrónico" class="form-control" id="email" name="email">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="">Sexo: *  </label>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="sexo" id="sexo" value="1" checked>
                                        <label class="form-check-label" for="f">
                                        Femenino
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="sexo" id="sexo" value="2">
                                        <label class="form-check-label" for="m">
                                        Masculino
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="">Área: *  </label>
                                </div>
                                <div class="col-md-8">
                                    <select class="form-control" name="areas" id="areas">
                                    <?php foreach ($area as $ar) {?>
                                        <option  value="<?php echo $ar['id']; ?>"><?php echo $ar['nombre']; ?></option>';
                                     <?php }?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="">Descripción: *  </label>
                                </div>
                                <div class="col-md-8">
                                    <textarea placeholder="Descripción de la experiencia del empleado" class="form-control" id="descripcion" name="descripcion"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                </div>
                                <div class="col-md-8">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="boletin" id="boletin" value="1">
                                        <label class="form-check-label" for="f">
                                        Deseo recibir boletín informativo.
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="" id="ro" name="ro">Roles: *  </label>
                                </div>
                                <div class="col-md-8">
                                <?php foreach ($roles as $rol) {?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="rol[]" id="rol" value="<?php echo $rol['id']; ?>" >
                                        <label class="form-check-label" >
                                        <?php echo $rol['nombre']; ?>
                                        </label>
                                    </div>
                                    <?php }?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label for="">Foto Empleado: </label>
                                </div>
                                <div class="col-md-8">
                                <label id="peso" name="peso">Peso Máximo: 200 kb, </label><label id="form" name="form"> Formato: "jpg", "png" </label>
                                <input type="file" id="file" name="file" />
                                </div>
                            </div>
                        </div>

                        <br>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                </div>
                                <div class="col-md-8">
                                <button type="submit" class="btn btn-danger" id="BtnGuardarEmpleado" >Guardar</button>
                                </div>
                            </div>
                        </div>
                    
                </form>
            </div>
        </div>
    </div>
</div>