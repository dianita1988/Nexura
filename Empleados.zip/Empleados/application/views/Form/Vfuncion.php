<script type="text/javascript">
//  $("#BtnGuardarEmpleado").click(function() {

// $('#FormEmpleado').validate({
// rules: {
//     nombre: { required: true},
//     email: { required: true},
//     descripcion: { required: true},
//     "rol[]": { required: true}
// },
// messages: {
//     nombre: {required:"Nombre requeridos"},
//     email: {required:"Correo requeridos"},
//     descripcion: {required:"Descripcion requeridos"},
//     "rol[]": {required: "Seleccione un rol"}
// },
// submitHandler: function(form){
//     event.preventDefault();
// $.ajax({
//     url: 'Dashboard/GuardarEmpleado',
//     type: 'Post',
//     data:$("#FormEmpleado").serialize(),
// })
// .done(function(response) {

//    if (response== '1') {
//      Swal.fire({
//       icon: 'success',
//       title: 'Registro guardado',
//       showConfirmButton: false,
//       timer: 2000
//   }).then(() => {

//     let table = $('#TablaEmpleado').DataTable();
//     table.ajax.reload(null, false);
// })

// }else{
// Swal.fire({
//   icon: 'error',
//   title: 'El registro no fue guardado',
//   showConfirmButton: false,
//   timer: 2000
// })
// }
// })
// .fail(function() {
//     console.log("error");
// })
// }
// })
// });

$("#BtnGuardarEmpleado").click(function(event) {
		if($("#nombre").val() == "")
		{
		    $("#nombre").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#nombre").css({"border":"1px solid green"});
		}
		
		if($("#email").val() == "" ){
		        $("#email").css({"border":"1px solid red"});
		        return false;
		}else{
		   valor =$("#email").val();
		    re=/^([\da-z_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
	        if(!re.exec(valor)){
	             $("#email").css({"border":"1px solid red"});
        		return false;
        	}else {
        	    $("#email").css({"border":"1px solid green"});
        	}
		}
		
        if($("#area").val() == "")
		{
		    $("#area").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#area").css({"border":"1px solid green"});
		}

        if($("#descripcion").val() == "")
		{
		    $("#descripcion").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#descripcion").css({"border":"1px solid green"});
		}

        if($("#boletin").val() == "")
		{
		    $("#boletin").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#boletin").css({"border":"1px solid green"});
		}

		var rolSeleccionados = new Array();
    $('input[type=checkbox]:checked').each(function() {
		rolSeleccionados.push($(this).val());
    });
		// var  cant = $('input[name="rol1[]"].checked').length
		// console.log(cant);
		if(rolSeleccionados == ""){
			$("#ro").css({"color":"red"});
			return false;
		}else{
			$("#ro").css({"color":"green"});
		}
		 
		// if ($('#rol').is(':checked')) {
		// 	$("#ro").css({"color":"green"});
		// }else{
		// 	$("#ro").css({"color":"red"});
		// 	return false;
		// }

		// if($("#file").val() == ""){
		// 		$("#file").css({"color":"red"});
		//     	return false;
		// 	}else{
		// 		$("#file").css({"color":"green"});
		// 	}

		if($("#sexo").val() == ""){
		     $("#sexo").css({"border":"1px solid red"});
		     return false;
		}else{
		    $("#sexo").css({"border":"1px solid green"});

		var formData = new FormData($("#FormEmpleado")[0]);
		$.ajax({
			url: 'Dashboard/GuardarEmpleado',
			type: 'POST',
			enctype: 'multipart/form-data',
			dataType: 'json',
			processData: false,
			contentType: false,
			cache: false,
			// data: $("#FormEmpleado").serialize() + "&file="+files,
			data: formData
		})
		.done(function(response) {
			if (response.codigo== 1) {
				Swal.fire({
							  icon: 'error',
							  title: response.mensaje,
							  showConfirmButton: false,
							  timer: 3000
							})
			}else{

				Swal.fire({
					  icon: 'success',
					  title: 'Registro Guardado',
					  showConfirmButton: false,
					  timer: 1500
					}).then(() => {

						 location.href = 'Dashboard'
					})
			}
		})
		.fail(function() {
			console.log("error");
		})
	}
	});
</script>