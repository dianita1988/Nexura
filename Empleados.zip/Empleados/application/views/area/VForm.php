<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row text-align"  >

    <div class="col-md-9">
            <div class="card shadow mb-6" id="formarea">
                <div class="col-lg-3">
					<div class="section-body" >
					<button type="button" class="btn ink-reaction btn-danger btncerrarcrear" id="btncerrarcrear" > X</button>
					</div>	
				</div>
                
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold" style="color: red;">Formulario de registro de Área</h6>
                </div>
                <div class="card-body">
                    <form id="FormArea" class="form-horizontal FormEmpleado" onsubmit="return false;" enctype="multipart/form-data">
       
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label  for="">Nombre Area: * </label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" placeholder="Nombre área" class="form-control" id="nombrea" name="nombrea">
                                </div>
                            </div>
                        </div>

                        <br>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                </div>
                                <div class="col-md-8">
                                <button type="submit" class="btn btn-danger" id="BtnGuardarArea" >Guardar</button>
                                </div>
                            </div>
                        </div>
                    
                    </form>
                </div>
            </div>
        </div>


        <div class="col-md-9">
            <div class="card shadow mb-6" id="formModifiarea">
            <div class="col-lg-3">
					<div class="section-body" >
					<button type="button" class="btn ink-reaction btn-danger btncerrarmod" id="btncerrarmod" > X</button>
					</div>	
				</div>
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold" style="color: red;">Formulario de modificación de Área</h6>
                </div>
                <div class="card-body">
                    <form id="FormModArea" class="form-horizontal FormEmpleado" onsubmit="return false;" enctype="multipart/form-data">
                    <input type="hidden" placeholder="Nombre área" class="form-control" id="idarea" name="idarea">
                        <div class="form-group">
                            <div class="row"> 
                                <div class="col-md-3 tex">
                                    <label  for="">Nombre Area: * </label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" placeholder="Nombre área" class="form-control" id="nombrearea1" name="nombrearea1">
                                </div>
                            </div>
                        </div>

                        <br>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                </div>
                                <div class="col-md-8">
                                <button type="submit" class="btn btn-danger" id="BtnModificarArea" >Guardar cambios</button>
                                </div>
                            </div>
                        </div>
                    
                    </form>
                </div>
            </div>
        </div>


    <div class="col-md-8" id="tablaarea">
        <div class="col-lg-6">
					<div class="section-body" >
					<button type="button" class="btn ink-reaction btn-primary btncrear" id="btncrear" ><i class='glyphicon glyphicon-plus'></i> AGREGAR ÁREA</button>
					</div> 
					</br>
				</div>
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold" style="color: red;">Tabla de registros</h6>
            </div>
            <div class="card-body">
                    <table id="TablaArea" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>AREA</th>
                                <th>ACCIONES</th>                           
                            </tr>
                        </thead>
                    </table>
            </div>
        </div>
    </div>
</div>