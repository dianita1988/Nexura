<script type="text/javascript">
 document.getElementById("formarea").style.display = "none";
 document.getElementById("formModifiarea").style.display = "none";
    $(document).ready(function() {
        $('#TablaArea').DataTable( {
            "processing": true,
            "serverSide": false,
            "responsive": true,
            "language": {
                "url": "./assets/Spanish.json"
            },
            "ajax": {
                "url": "Area/TablaArea",
                "type": "POST"
            },
            "columns": [
            { "data": "id",visible: false },
            { "data": "nombre" },
            {'data': null, "className": "text-center",
            'render': function (data, type, row) 
             {
                return '<button  class="btn .ink-reaction btn-info" onclick="editarregistro('+row.id+',\''+ row.nombre + '\')"><i class="fa fa-fw fa-edit"></i></button>';
             }
        },
            ]
        } );
    } );

    function refrescartabla(){
    var table = $('#TablaArea').DataTable();
     table.ajax.reload(null,false);  
    }

    $("#btncrear").click(function() {
      document.getElementById("formarea").style.display = "block";
      document.getElementById("tablaarea").style.display = "none";
});

$("#btncerrarcrear").click(function() {
      document.getElementById("FormArea").style.display = "none";
      document.getElementById("tablaarea").style.display = "block";
});

$("#btncerrarmod").click(function() {
      document.getElementById("formModifiarea").style.display = "none";
      document.getElementById("tablaarea").style.display = "block";
});

$("#BtnGuardarArea").click(function(event) {
      if($("#nombre").val() == "")
		{
		    $("#nombre").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#nombre").css({"border":"1px solid green"});
		}

        $.ajax({
            url: 'Area/GuardarArea',
            type: 'Post',
            data:$("#FormArea").serialize(),
        })
        .done(function(response) {

           if (response== '1') {
             Swal.fire({
              icon: 'success',
              title: 'Registro guardado',
              showConfirmButton: false,
              timer: 2000
          }).then(() => {
            location.href = 'Area'
        })

      }else{
        Swal.fire({
          icon: 'error',
          title: 'El registro no fue guardado',
          showConfirmButton: false,
          timer: 2000
      })
    }
	});
});

    function eliminarregistro(id)
{
  alert(id);
  Swal.fire({
  title: '¿Estás seguro?',
  text: "Que desea eliminar esta empleado",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Si'
}).then((result) => {
  if (result.isConfirmed) {
    $.ajax({
          type:"post",
          url: "Lista/eliminar",
          data: {id},
                    success:function(respuesta)
                    {
                      Swal.fire({
                        icon: 'danger',
                        title: 'Registro eliminado',
                        showConfirmButton: false,
                        timer: 2000
                      }).then(() => {

                        refrescartabla();
                      })
                    }
           });

  } else {
}
});

}

  function editarregistro(id,nombre)
  {
    alert(nombre);
    document.getElementById("formModifiarea").style.display = "block";
    document.getElementById("tablaarea").style.display = "none";
    $("#idarea").val(id);
    $("#nombrearea1").val(nombre);
  }

  $("#BtnModificarArea").click(function() {
    if($("#nombrearea1").val() == "")
		{
		    $("#nombrearea1").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#nombrearea1").css({"border":"1px solid green"});

        $.ajax({
            url: 'Area/modificar',
            type: 'Post',
            data:$("#FormModArea").serialize(),
        })
		.done(function(response) {
			if (response.codigo== 1) {
				Swal.fire({
							  icon: 'error',
							  title: response.mensaje,
							  showConfirmButton: false,
							  timer: 3000
							})
			}else{

				Swal.fire({
					  icon: 'success',
					  title: 'Registro Actualizado',
					  showConfirmButton: false,
					  timer: 1500
					}).then(() => {

						 location.href = 'Area'
					})
			}
		})
		.fail(function() {
			console.log("error");
		})
  }

});

</script>