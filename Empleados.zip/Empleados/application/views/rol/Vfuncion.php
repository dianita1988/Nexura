<script type="text/javascript">
 document.getElementById("formarol").style.display = "none";
 document.getElementById("formModifirol").style.display = "none";
    $(document).ready(function() {
        $('#TablaRol').DataTable( {
            "processing": true,
            "serverSide": false,
            "responsive": true,
            "language": {
                "url": "./assets/Spanish.json"
            },
            "ajax": {
                "url": "Rol/TablaRoles",
                "type": "POST"
            },
            "columns": [
            { "data": "id",visible: false },
            { "data": "nombre" },
            {'data': null, "className": "text-center",
            'render': function (data, type, row) 
             {
                return '<button  class="btn .ink-reaction btn-info" onclick="editarregistro('+row.id+',\''+ row.nombre + '\')"><i class="fa fa-fw fa-edit"></i></button>';
             }
        },
            ]
        } );
    } );

    function refrescartabla(){
    var table = $('#tablarol').DataTable();
     table.ajax.reload(null,false);  
    }

    $("#btncrear").click(function() {
      document.getElementById("formarol").style.display = "block";
      document.getElementById("tablarol").style.display = "none";
});

$("#btncerrarcrear").click(function() {
      document.getElementById("Formrol").style.display = "none";
      document.getElementById("tablarol").style.display = "block";
});

$("#btncerrarmod").click(function() {
      document.getElementById("formModifirol").style.display = "none";
      document.getElementById("tablarol").style.display = "block";
});

$("#BtnGuardarRol").click(function(event) {
      if($("#nombre").val() == "")
		{
		    $("#nombre").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#nombre").css({"border":"1px solid green"});
		}

        $.ajax({
            url: 'Rol/GuardarRol',
            type: 'Post',
            data:$("#FormRol").serialize(),
        })
        .done(function(response) {

           if (response== '1') {
             Swal.fire({
              icon: 'success',
              title: 'Registro guardado',
              showConfirmButton: false,
              timer: 2000
          }).then(() => {
            location.href = 'Rol'
        })

      }else{
        Swal.fire({
          icon: 'error',
          title: 'El registro no fue guardado',
          showConfirmButton: false,
          timer: 2000
      })
    }
	});
});

    function eliminarregistro(id)
{
  alert(id);
  Swal.fire({
  title: '¿Estás seguro?',
  text: "Que desea eliminar esta empleado",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Si'
}).then((result) => {
  if (result.isConfirmed) {
    $.ajax({
          type:"post",
          url: "Lista/eliminar",
          data: {id},
                    success:function(respuesta)
                    {
                      Swal.fire({
                        icon: 'danger',
                        title: 'Registro eliminado',
                        showConfirmButton: false,
                        timer: 2000
                      }).then(() => {

                        refrescartabla();
                      })
                    }
           }); 

  } else {
}
});

}

  function editarregistro(id,nombre)
  {
    document.getElementById("formModifirol").style.display = "block";
    document.getElementById("tablarol").style.display = "none";
    $("#idrol").val(id);
    $("#nombrerol1").val(nombre);
  }

  $("#BtnModificaRol").click(function() {
    if($("#nombrerol1").val() == "")
		{
		    $("#nombrerol1").css({"border":"1px solid red"});
		    return false;
		}else{
		     $("#nombrerol1").css({"border":"1px solid green"});

        $.ajax({
            url: 'Rol/modificar',
            type: 'Post',
            data:$("#FormModRol").serialize(),
        })
		.done(function(response) {
			if (response.codigo== 1) {
				Swal.fire({
							  icon: 'error',
							  title: response.mensaje,
							  showConfirmButton: false,
							  timer: 3000
							})
			}else{

				Swal.fire({
					  icon: 'success',
					  title: 'Registro Actualizado',
					  showConfirmButton: false,
					  timer: 1500
					}).then(() => {

						 location.href = 'Rol'
					})
			}
		})
		.fail(function() {
			console.log("error");
		})
  }

});

</script>