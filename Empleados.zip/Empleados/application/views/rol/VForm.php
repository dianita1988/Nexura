<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row text-align"  >

    <div class="col-md-9">
            <div class="card shadow mb-6" id="formarol">
                <div class="col-lg-3">
					<div class="section-body" >
					<button type="button" class="btn ink-reaction btn-danger btncerrarcrear" id="btncerrarcrear" > X</button>
					</div>	
				</div>
                
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold" style="color: red;">Formulario de registro de Rol</h6>
                </div>
                <div class="card-body">
                    <form id="FormRol" class="form-horizontal FormEmpleado" onsubmit="return false;" enctype="multipart/form-data">
       
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                    <label  for="">Nombre Rol: * </label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" placeholder="Nombre área" class="form-control" id="nombrea" name="nombrea">
                                </div>
                            </div>
                        </div>

                        <br>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                </div>
                                <div class="col-md-8">
                                <button type="submit" class="btn btn-danger" id="BtnGuardarRol" >Guardar</button>
                                </div>
                            </div>
                        </div>
                    
                    </form>
                </div>
            </div>
        </div>


        <div class="col-md-9">
            <div class="card shadow mb-6" id="formModifirol">
            <div class="col-lg-3">
					<div class="section-body" >
					<button type="button" class="btn ink-reaction btn-danger btncerrarmod" id="btncerrarmod" > X</button>
					</div>	
				</div>
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold" style="color: red;">Formulario de modificación de Área</h6>
                </div>
                <div class="card-body">
                    <form id="FormModRol" class="form-horizontal FormEmpleado" onsubmit="return false;" enctype="multipart/form-data">
                    <input type="hidden" placeholder="Nombre área" class="form-control" id="idrol" name="idrol">
                        <div class="form-group">
                            <div class="row"> 
                                <div class="col-md-3 tex">
                                    <label  for="">Nombre Rol: * </label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" placeholder="Nombre área" class="form-control" id="nombrerol1" name="nombrerol1">
                                </div>
                            </div>
                        </div>

                        <br>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3 tex">
                                </div>
                                <div class="col-md-8">
                                <button type="submit" class="btn btn-danger" id="BtnModificaRol" >Guardar cambios</button>
                                </div>
                            </div>
                        </div>
                    
                    </form>
                </div>
            </div>
        </div>


    <div class="col-md-8" id="tablarol">
        <div class="col-lg-6">
					<div class="section-body" >
					<button type="button" class="btn ink-reaction btn-primary btncrear" id="btncrear" ><i class='glyphicon glyphicon-plus'></i> AGREGAR ROL</button>
					</div> 
					</br>
				</div>
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold" style="color: red;">Tabla de registros</h6>
            </div>
            <div class="card-body">
                    <table id="TablaRol" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>ROL</th>
                                <th>ACCIONES</th>                           
                            </tr>
                        </thead>
                    </table>
            </div>
        </div>
    </div>
</div>