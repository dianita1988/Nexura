<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rol extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('MRol');
		$this->load->model('MEmpleado');
	}

	public function index()
	{
		$this->load->view('header/VHeader');
		$this->load->view('rol/VForm');
		$this->load->view('footer/VFooter');
		$this->load->view('rol/Vfuncion.php');
	}

	public function GuardarRol()
	{	
		$nombre = $this->input->post('nombrea');
		$ejecucion= $this->MRol->GuardarRol($nombre);
		if ($ejecucion['code']== 0) {
			echo '1';
		}else{
			echo '0';
		}
		
	}

	public function TablaRoles()
	{
		$ejecucion['data']=$this->MEmpleado->TablaRoles();
		echo json_encode($ejecucion);
	}

	public function eliminar()
	{	
		$id = $_POST['id'];
		$this->MRol->EliminarRol($id);
		redirect('Rol');
	}

	public function modificar(){
		$nombre = $this->input->post('nombrerol1');
		$id = $this->input->post('idrol');
		$ejecucion= $this->MRol->ModificRol($id,$nombre);
		if ($ejecucion['code'] == 0) {
			echo '1';
		}else{
			echo '0';
		}
	}

}
