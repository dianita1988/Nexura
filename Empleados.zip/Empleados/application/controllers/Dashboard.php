<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('MEmpleado');
	}

	public function index()
	{
		$this->load->view('header/VHeader');
		$dato['area']=$this->MEmpleado->TablaArea();
		$dato['roles']=$this->MEmpleado->TablaRoles();
		$this->load->view('form/VForm',$dato);
		$this->load->view('footer/VFooter');
		$this->load->view('form/Vfuncion.php');
	}

	public function GuardarEmpleado()
	{	
		if($_FILES['file']['name'] == null){
			$foto =  "";
		}else{
		$ejecutar=$this->guardar_foto('file');
		$foto =  $ejecutar['ruta'];
		}
		// move_uploaded_file($_FILES['file']['tmp_name'], './upload/'.$_FILES['file']['name']);
		//$ejecutar=$this->guardar_foto('file');

		if (array_key_exists("boletin",$this->input->post()))
		{
			$boletin = $this->input->post('boletin');
		}
		else
		{
			$boletin = 0;
		}
		// if(!empty($this->input->post('boletin'))){
		// 	$boletin = $this->input->post('boletin');
		// }else{
		// 	$boletin = 0;
		// }
			$nombre =$this->input->post('nombre');
			$email =$this->input->post('email');
			$sexo =$this->input->post('sexo');
			$area =$this->input->post('areas');
			$descripcion =$this->input->post('descripcion');
			//$foto =  $ejecutar['ruta'];
			$id= $this->MEmpleado->GuardarEmpl($nombre,$email,$sexo,$area,$boletin,$descripcion,$foto);
			if ($id == "") {	
				echo '1';
			}else{
				if ($_POST['rol'] != "") {
					if (is_array($_POST['rol'])) {
						for ($i=0; $i < count($_POST['rol']); $i++) { 
							$rol = $_POST['rol'][$i];
							$this->MEmpleado->GuardarRol($id,$rol);
						}
						
					}
				}
				echo '0';
			}
	}

	public function guardar_foto($file){

		$config['upload_path']          = './upload/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 5000;
		$config['max_width']            = 1024;
		$config['max_height']           = 768;

		$this->load->library('upload', $config);

		if (!$this->upload->do_upload($file))
		{
				$data = array('error' => 'error');

		}
		else
		{
				$datos=$this->upload->data();
				$data = array('ruta' => './upload/'.$datos['file_name']);
		}

		return $data;
	}

	

}
