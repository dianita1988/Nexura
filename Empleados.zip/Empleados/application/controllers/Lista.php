<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lista extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('MEmpleado');
	}

	public function index()
	{
		$this->load->view('header/VHeader');
		$dato['area']=$this->MEmpleado->TablaArea();
		$dato['roles']=$this->MEmpleado->TablaRoles();
		$this->load->view('List/VList',$dato);
		$this->load->view('footer/VFooter');
		$this->load->view('List/Vfuncion.php');
	}

	public function TablaEmpleado()
	{
		$ejecucion=$this->MEmpleado->TablaEmpleado();
		$i=0;
		$roles='';
		$nuevoarray=array();
		$result = array();
		foreach ($ejecucion as $element) {
			$resultado[$element['id']][] = $element;
		}
		$llaves=array_keys($resultado);
		while ($i < count($llaves)) 
		{
			$ii=0;
			$roles='';
			 while ($ii < count($resultado[$llaves[$i]])) 
			 {
				$roles.= $resultado[$llaves[$i]][$ii]['ROLES'].',';
				 $ii++;
			 }
			 $jj=0;
			 while ($jj < count($resultado[$llaves[$i]])) 
			 {
				 $resultado[$llaves[$i]][$jj]['rolestotales'] = rtrim($roles,',');
				 $jj++;
			 }
			 $nuevoarray[]= $resultado[$llaves[$i]][0];
			$i++;
		}
		$ejecucion2['data']=$nuevoarray;
		echo json_encode($ejecucion2);
	}

	public function ConsultarRol()
	{
		$id = $_POST['id'];
		$ejecucion= $this->MEmpleado->ConsultaRol($id);
		print_r($ejecucion); exit;
		echo json_encode($ejecucion);
	}

	public function eliminar()
	{	
		$id = $_POST['id'];
		$this->MEmpleado->EliminarEmpl($id);
		redirect('Lista');
	}

	public function modificar(){
	//move_uploaded_file($_FILES['file']['tmp_name'], './upload/'.$_FILES['file']['name']);
	if($_FILES['file']['name'] == null){
		$foto =  $this->input->post('fot');
	}else{
	$ejecutar=$this->guardar_foto('file');
	$foto =  $ejecutar['ruta'];
	}
	if (array_key_exists("boletin1",$this->input->post()))
	{
		$boletin = $this->input->post('boletin1');
	}
	else
	{
		$boletin = 0;
	}
		$id = $this->input->post('id');
		$nombre =$this->input->post('nombre1');
		$email =$this->input->post('email1');
		$sexo =$this->input->post('sexo1');
		$area =$this->input->post('areas1');
		$descripcion =$this->input->post('descripcion1');
		
		$id= $this->MEmpleado->ModificarEmpl($id,$nombre,$email,$sexo,$area,$boletin,$descripcion,$foto);
		if ($id == "") {	
			echo '1';
		}else{
			if ($_POST['rol'] != "") {
				if (is_array($_POST['rol1'])) {
					for ($i=0; $i < count($_POST['rol1']); $i++) { 
						$rol = $_POST['rol1'][$i];
						$this->MEmpleado->ModificarRol($id,$rol);
					}					
				}
			}
			echo '0';
		}
}

public function guardar_foto($file){

	$config['upload_path']          = './upload/';
	$config['allowed_types']        = 'gif|jpg|png';
	$config['max_size']             = 5000;
	$config['max_width']            = 1024;
	$config['max_height']           = 768;

	$this->load->library('upload', $config);

	if (!$this->upload->do_upload($file))
	{
			$data = array('error' => 'error');

	}
	else
	{
			$datos=$this->upload->data();
			$data = array('ruta' => './upload/'.$datos['file_name']);
	}

	return $data;
}

}
