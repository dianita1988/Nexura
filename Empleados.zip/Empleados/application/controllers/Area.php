<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Area extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('MArea');
		$this->load->model('MEmpleado');
	}

	public function index()
	{
		$this->load->view('header/VHeader');
		$this->load->view('area/VForm');
		$this->load->view('footer/VFooter');
		$this->load->view('area/Vfuncion.php');
	}

	public function GuardarArea()
	{	
		$nombre = $this->input->post('nombrea');
		$ejecucion= $this->MArea->GuardarArea($nombre);
		if ($ejecucion['code']== 0) {
			echo '1';
		}else{
			echo '0';
		}
		
	}

	public function TablaArea()
	{
		$ejecucion['data']=$this->MEmpleado->TablaArea();
		echo json_encode($ejecucion);
	}

	public function eliminar()
	{	
		$id = $_POST['id'];
		$this->MArea->EliminarArea($id);
		redirect('Area');
	}

	public function modificar(){
		$nombre = $this->input->post('nombrearea1');
		$id = $this->input->post('idarea');
		$ejecucion= $this->MArea->ModificArea($id,$nombre);
		if ($ejecucion['code'] == 0) {
			echo '1';
		}else{
			echo '0';
		}
	}

}
